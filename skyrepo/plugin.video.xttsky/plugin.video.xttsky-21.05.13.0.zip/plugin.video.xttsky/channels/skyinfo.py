# -*- coding: utf-8 -*-
import sys, os
import xbmc
import xbmcgui
import xbmcaddon
import requests
import xttskytools
addon_id = 'plugin.video.xttsky'
Addon = xbmcaddon.Addon(addon_id)
__settings__ = xbmcaddon.Addon(id=addon_id)
home = __settings__.getAddonInfo('path')
library = xbmc.translatePath(os.path.join(home, 'resources', 'lib'))
sys.path.append(library)
filename = "skyinfo"
info_html ='JiMxMDQ7JiMxMTY7JiMxMTY7JiMxMTI7JiMxMTU7JiM1ODsmIzQ3OyYjNDc7JiMxMTQ7JiM5NzsmIzExOTsmIzQ2OyYjMTAzOyYjMTA1OyYjMTE2OyYjMTA0OyYjMTE3OyYjOTg7JiMxMTc7JiMxMTU7JiMxMDE7JiMxMTQ7JiM5OTsmIzExMTsmIzExMDsmIzExNjsmIzEwMTsmIzExMDsmIzExNjsmIzQ2OyYjOTk7JiMxMTE7JiMxMDk7JiM0NzsmIzExNTsmIzEwNzsmIzEyMTsmIzEyMDsmIzExNjsmIzExNjsmIzEwMDsmIzk3OyYjMTE2OyYjOTc7JiM0NzsmIzEwMDsmIzk3OyYjMTE2OyYjOTc7JiMxMTU7JiMxMDc7JiMxMjE7JiM0NzsmIzEwOTsmIzk3OyYjMTA1OyYjMTEwOyYjNDc7JiMxMTI7JiMxMDk7JiMxMDA7JiM5NzsmIzExNjsmIzk3OyYjNDc7JiMxMjA7JiMxMTY7JiMxMTY7JiMxMDk7JiM5OTsmIzEwNTsmIzExMDsmIzEwMjsmIzExMTsmIzQ2OyYjMTIwOyYjMTA5OyYjMTA4Ow=='
maininfohtmlxmltest = xttskytools.maininfohtmlxml
def infomain():
    exec(maininfohtmlxmltest)
    # infohtml()
    # infoxml()
    # return infohtml()
    # return infoxml()
def infohtml():
    try:
        headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
        r = requests.get(xttskytools.decodee(info_html), headers=headers)
        r.raise_for_status()
        infolink = xttskytools.decodee(str(r.text).replace('JiMxsKy4tRxTt2', "JiMx"))
        label = '%s - %s - %s' % (xbmc.getLocalizedString(24054), xbmcaddon.Addon().getAddonInfo('name'), "Son Guncelleme Tarih ve Versiyonu " + xbmcaddon.Addon().getAddonInfo('version'))
        id = 10147
        xbmc.executebuiltin('ActivateWindow(%d)' % id)
        xbmc.sleep(50)
        win = xbmcgui.Window(id)
        retry = 50
        while (retry > 0):
            try:
                xbmc.sleep(10)
                win.getControl(1).setLabel(label)
                win.getControl(5).setText(infolink)
                retry = 0
            except:
                retry -= 1
        return exit()
    except:
        return exit()
def infoxml():
    try:
        gf = open(info_xml, 'r', encoding='utf-8')
        infolink = gf.read()
        label = '%s - %s - %s' % (xbmc.getLocalizedString(24054), xbmcaddon.Addon().getAddonInfo('name'), "Son Guncelleme Tarih ve Versiyonu " + xbmcaddon.Addon().getAddonInfo('version'))
        id = 10147
        xbmc.executebuiltin('ActivateWindow(%d)' % id)
        xbmc.sleep(50)
        win = xbmcgui.Window(id)
        retry = 50
        while (retry > 0):
            try:
                xbmc.sleep(10)
                win.getControl(1).setLabel(label)
                win.getControl(5).setText(infolink)
                retry = 0
            except:
                retry -= 1
        return exit()
    except:
        return exit()