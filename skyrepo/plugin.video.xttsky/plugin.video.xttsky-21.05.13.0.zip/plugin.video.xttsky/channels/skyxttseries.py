# -*- coding: utf-8 -*-
import re, os
import sys
import urllib
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import requests
import xttskytools
import time
addon_id = 'plugin.video.xttsky'
Addon = xbmcaddon.Addon(addon_id)
__settings__ = xbmcaddon.Addon(id=addon_id)
home = __settings__.getAddonInfo('path')
library = xbmc.translatePath(os.path.join(home, 'resources', 'lib'))
sys.path.append(library)
images_path = xbmc.translatePath(os.path.join(home, 'resources','images'))
sys.path.append(images_path)
# channels = xbmc.translatePath(os.path.join(home, 'channels'))
# sys.path.append(channels)
Fanart = images_path+'/Fanartbackground.jpg'
addon_icon = __settings__.getAddonInfo('icon')
filename = "skyxttseries"
xbmcPlayer = xbmc.Player()
xbmcPlayer.stop()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
playList.clear()
################# SERIES ###################
def xttskyseries(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo):
    print (name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo)
    mac = str(mac)
    panelurl = str(url)
    tokenkey = handshake(panelurl,mac,timezone)
    timezone = getProfile(panelurl,mac,tokenkey,timezone)
    info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
        'type' : 'series', 
        'action' : 'get_categories',
        'JsHttpRequest' : '1-xml',
        'mac' : mac})
    results = info['js']
    for listeler in results:
        if  not listeler['id'] != '*':
            pass
        else:
            idler = listeler['id']
            title= listeler['title']
            logo = images_path + "/xttsmart.png"
            xttplaymeta(filename,"xttskyseriesgenre(title,name,sezon,bolum,thumbnail,thumbfolder,panelurl,mac,tokenkey,timezone,cmd,data1,data2,data3,data4,data5,data6,metainfo)","title",str(title),"sezon","bolum",str(logo),"thumbfolder",str(panelurl),str(mac),str(tokenkey),str(timezone),"cmd",str(idler),"data2","data3","data4","data5","data6","metainfo")
    # xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmc.executebuiltin("Container.SetViewMode(500)")
def xttskyseriesgenre(title,name,sezon,bolum,thumbnail,thumbfolder,panelurl,mac,tokenkey,timezone,cmd,data1,data2,data3,data4,data5,data6,metainfo):
# def xttskyseriesgenre(title,name,panelurl,mac,thumbnail,thumbfolder,tokenkey,timezone,cmd,data1,data2,data3,data4,data5,data6,metainfo):
    # title = str(name)
    title = str(name)
    mac = str(mac)
    panelurl = str(panelurl)
    tokenkey = handshake(panelurl,mac,timezone)
    timezone = getProfile(panelurl,mac,tokenkey,timezone)
    for page in range(1, 500):
        info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
            'type' : 'series', 
            'action' : 'get_ordered_list',
            'category' : data1,
            'movie_id' : '0',
            'season_id' : '0',
            'episode_id' : '0',
            'fav' : '0',
            'p' : page,
            'JsHttpRequest' : '1-xml'})
        results = info['js']['data']
        if not results !=[]:
            break
        else:
            for listeler in results:
                name = listeler["name"]
                idler = listeler['id']
                category_id= listeler['category_id']
                logo = listeler['screenshot_uri']
                if not logo !="":
                    logo = images_path + "/xttsmart.png"
                else:
                    logo = logo
                labelsgroup = []
                try:
                    if not listeler['genres_str'] !="N/A" or not listeler['genres_str'] !="N/a" or not listeler['genres_str'] !="n/a" or not listeler['genres_str'] !="n/A" or not listeler['genres_str'] !=0:
                        pass
                    else:
                        tur = '[B][COLOR blue]Tür : [/COLOR][/B][B][COLOR darkgray]'+listeler['genres_str']+'[/COLOR][/B]'
                        labelsgroup.append((tur))
                except: pass
                try:
                    if not listeler['director'] !="N/A" or not listeler['director'] !="N/a" or not listeler['director'] !="n/a" or not listeler['director'] !="n/A" or not listeler['director'] !=0:
                        pass
                    else:
                        director = '[B][COLOR blue]Yönetmen : [/COLOR][/B][B][COLOR darkgray]'+listeler['director']+'[/COLOR][/B]'
                        labelsgroup.append((director))
                except: pass
                try:
                    if not listeler['actors'] !="N/A" or not listeler['actors'] !="N/a" or not listeler['actors'] !="n/a" or not listeler['actors'] !="n/A" or not listeler['actors'] !=0:
                        pass
                    else:
                        actors = '[B][COLOR blue]Oyuncular : [/COLOR][/B][B][COLOR darkgray]'+listeler['actors']+'[/COLOR][/B]'
                        labelsgroup.append((actors))
                except: pass
                try:
                    if not listeler['year'] !="N/A" or not listeler['year'] !="N/a" or not listeler['year'] !="n/a" or not listeler['year'] !="n/A" or not listeler['year'] !=0:
                        pass
                    else:
                        year = '[B][COLOR blue]Yapım Yılı : [/COLOR][/B][B][COLOR darkgray]'+listeler['year']+'[/COLOR][/B]'
                        labelsgroup.append((year))
                except: pass
                puantime = []
                try:
                    try:
                        if not listeler['time'] !="N/A" or not listeler['time'] !="N/a" or not listeler['time'] !="n/a" or not listeler['time'] !="n/A" or not listeler['time'] !=0:
                            pass
                        else:
                            time = '[B][COLOR blue]Süre : [/COLOR][/B][B][COLOR darkgray]'+str(listeler['time'])+'[/COLOR][/B]'
                            puantime.append((str(time)))
                    except: pass
                    try:
                        if not listeler['rating_imdb'] !="N/A" or not listeler['rating_imdb'] !="N/a" or not listeler['rating_imdb'] !="n/a" or not listeler['rating_imdb'] !="n/A" or not listeler['rating_imdb'] !=0:
                            pass
                        else:
                            rating = '[B][COLOR blue]IMBD : [/COLOR][/B][B][COLOR darkgray]'+listeler['rating_imdb']+'[/COLOR][/B]'
                            puantime.append((rating))
                    except: pass
                except: pass
                if not puantime !=[]:
                    pass
                else:
                    timeimbd = str(puantime).replace('", "', "  ").replace('\', "', "  ").replace('", \'', "  ").replace("['", "").replace('["', "").replace("']", "").replace('"]', "").replace("', '", "    ").replace('", "', "    ").replace('\', "', "    ").replace('", \'', "    ")
                    labelsgroup.append((timeimbd))
                # try:
                    # MPAA = '[B][COLOR blue]MPAA : [/COLOR][/B][B][COLOR darkgray]'+listeler['rating_kinopoisk']+'[/COLOR][/B]'
                    # labelsgroup.append((MPAA))
                # except: pass
                
                # try:
                    # if not listeler['age'] !="N/A":
                        # pass
                    # else:
                        # age = '[B][COLOR blue]Yaş Sınırı : [/COLOR][/B][B][COLOR darkgray]'+listeler['age']+'[/COLOR][/B]'
                        # labelsgroup.append((age))
                # except: pass
                try:
                    if not listeler['description'] !="N/A" or not listeler['description'] !="N/a" or not listeler['description'] !="n/a" or not listeler['description'] !="n/A" or not listeler['description'] !=0:
                        pass
                    else:
                        plot = '[B][COLOR blue]Konu : [/COLOR][/B][B][COLOR yellow]'+listeler['description']+'[/COLOR][/B]'
                        labelsgroup.append((plot))
                except: pass
                if not labelsgroup !=[]:
                    labels = "[B][COLOR blue]"+name+"[/COLOR][/B]"
                else:
                    labels = replace_fix(str(labelsgroup))
                xttplaymeta(filename,"xttskyseriesprog(title,name,sezon,bolum,thumbnail,thumbfolder,panelurl,mac,tokenkey,timezone,cmd,data1,data2,data3,data4,data5,data6,metainfo)",str(name),str(name),"sezon","bolum",str(logo),"thumbfolder",str(panelurl),str(mac),str(tokenkey),str(timezone),"cmd",str(idler),str(category_id),"data3","data4","data5","data6",labels)
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmc.executebuiltin("Container.SetViewMode(54)")
    # xbmc.executebuiltin("Container.SetViewMode(500)")
def xttskyseriesprog(title,name,sezon,bolum,thumbnail,thumbfolder,panelurl,mac,tokenkey,timezone,cmd,data1,data2,data3,data4,data5,data6,metainfo):
    mac = str(mac)
    panelurl = str(panelurl)
    tokenkey = handshake(panelurl,mac,timezone)
    timezone = getProfile(panelurl,mac,tokenkey,timezone)
    for page in range(1, 500):
        info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
            'type' : 'series', 
            'action' : 'get_ordered_list',
            'movie_id' : data1,
            'category' : data1,
            'season_id' : '0',
            'episode_id' : '0',
            'fav' : '0',
            'p' : page,
            'JsHttpRequest' : '1-xml'})
        results = (info['js']['data'])[::-1]
        if not results !=[]:
            break
        else:
            for listeler in results:
                name = listeler["name"]
                idler = listeler['id']
                cmd = listeler['cmd']
                series = listeler['series']
                logo = listeler['screenshot_uri']
                if not logo !="":
                    logo = images_path + "/xttsmart.png"
                else:
                    logo = logo
                xttplaymeta(filename,"xttskyseriessezon(title,name,sezon,bolum,thumbnail,thumbfolder,panelurl,mac,tokenkey,timezone,cmd,data1,data2,data3,data4,data5,data6,metainfo)",str(title),str(name),str(name),"bolum",str(logo),"thumbfolder",str(panelurl),str(mac),str(tokenkey),str(timezone),str(cmd),str(idler),"data2",str(len(series)),"data4","data5","data6",metainfo)
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    # xbmc.executebuiltin("Container.SetViewMode(54)")
    # xbmc.executebuiltin("Container.SetViewMode(500)")
def xttskyseriessezon(title,name,sezon,bolum,thumbnail,thumbfolder,panelurl,mac,tokenkey,timezone,cmd,data1,data2,data3,data4,data5,data6,metainfo):
    mac = str(mac)
    panelurl = str(panelurl)
    tokenkey = handshake(panelurl,mac,timezone)
    timezone = getProfile(panelurl,mac,tokenkey,timezone)
    sezonbolum = int(data3)+1
    for page in range(1, sezonbolum):
        name = sezon + " Bolum : "+str(page)
        xttplaymeta(filename,"testplayermeta(title,name,sezon,bolum,thumbnail,thumbfolder,panelurl,mac,tokenkey,timezone,cmd,data1,data2,data3,data4,data5,data6,metainfo)",str(title),str(name),"sezon",str(name),str(thumbnail),"thumbfolder",str(panelurl),str(mac),str(tokenkey),str(timezone),str(cmd),"data1","data2","data3",str(page),"data5","data6",metainfo)
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    # xbmc.executebuiltin("Container.SetViewMode(54)")
    # xbmc.executebuiltin("Container.SetViewMode(500)")

def testplayermeta(title,name,sezon,bolum,thumbnail,thumbfolder,panelurl,mac,tokenkey,timezone,cmd,data1,data2,data3,data4,data5,data6,metainfo):
    name = '[B][COLOR blue]'+title+'[/COLOR][/B][B][COLOR darkgray] - [/COLOR][/B][B][COLOR whitesmoke]'+name+'[/COLOR][/B]'
    mac = str(mac)
    panelurl = str(panelurl)
    tokenkey = handshake(panelurl,mac,timezone)
    timezone = getProfile(panelurl,mac,tokenkey,timezone)
    Datasearch(panelurl,mac,tokenkey,timezone,values = {
        'type' : 'watchdog',
        'action' : 'get_events',
        'init' : '0',
        'cur_play_type' : '1',
        'event_active_id' : '0'})
    info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
        'type' : 'vod',
        'action' : 'create_link',
        'cmd' : str(cmd),
        'series' : str(data4),
        'JsHttpRequest' : '1-xml'});
    cmd = info['js']['cmd'];
    # print (cmd)
    # s = cmd.split(' ');
    # url = s[0];
    # if len(s)>1:
        # url = s[1];
    url = str(cmd).replace('ffmpeg ', '')
    if thumbnail != "":
        thumbfolder = os.path.join(images_path, "xttsmart.png")
    listitem = xbmcgui.ListItem(name)
    listitem.setArt({'thumb': thumbnail or thumbfolder})
    listitem.setInfo('video', infoLabels={"plot": str(metainfo)})
    playList.add(url,listitem=listitem)
    xbmcPlayer.play(playList)
    # playList.clear(exit())
    return playList.clear(exit())
    
    # progress = xbmcgui.DialogProgress()
    # progress.create('Kontrol Ediliyor...', 'Lütfen Bekleyin...')
    # progress.update(15)
    # xbmc.sleep(50)
    # if thumbnail != "":
        # thumbfolder = os.path.join(images_path, "xttsmart.png")
    # listitem = xbmcgui.ListItem()
    # listitem.setArt({'thumb': thumbnail or thumbfolder})
    # listitem.setInfo('Video', {'title': name,
     # 'Seekable': 'false',
     # 'SeekEnabled': 'false'})
    # listitem.setInfo('Video', infoLabels={"plot": str(metainfo)})
    # listitem.setLabel(name)
    # listitem.setPath(url)
    # listitem.setProperty('IsPlayable', 'true')
    # listitem.setProperty('IsNotSeekable', 'true')
    # listitem.setProperty('Seekable', 'false')
    # listitem.setProperty('SeekEnabled', 'false')
    # progress.update(30)
    # xbmcPlayer.play(url,listitem)
    # progress.update(45)
    # abortReason = ''
    # step = 1
    # t = time.time()
    # player = xbmc.Player()
    # monitor = xbmc.Monitor()
    # while not abortReason:
        # if monitor.abortRequested():
            # abortReason = 'aborted'
        # elif progress.iscanceled():
            # abortReason = 'cancelled'
        # elif time.time() - t > 60:
            # abortReason = 'timeout'
        # elif step == 1:
            # if player.isPlaying():
                # progress.update(60)
                # step = 2
        # elif step == 2:
            # if xbmc.getInfoLabel('VideoPlayer.VideoResolution'):
                # progress.update(75)
                # step = 3
        # elif step == 3:
            # if True or player.isPlaying() and player.getTime() > 0.1:
                # progress.update(100)
                # break
        # if not abortReason:
            # xbmc.sleep(250)
    # xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=listitem,isFolder=False)

# xttplaymeta(filename,"xttskyseriesprog(title,name,panelurl,mac,thumbnail,thumbfolder,tokenkey,timezone,cmd,data1,data2,data3,data4,data5,data6,metainfo)","title",str(name),str(panelurl),str(mac),str(logo),"thumbfolder",str(tokenkey),str(timezone),"cmd",str(idler),str(category_id),"data3","data4","data5","data6","metainfo")
# xttplaymeta(filename,method,title,name,panelurl,mac,thumbnail,thumbfolder,tokenkey,timezone,cmd,data1,data2,data3,data4,data5,data6,metainfo)
def handshake(panelurl,mac,timezone):
    tokenkey = ""
    info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
        'type' : 'stb', 
        'action' : 'handshake',
        'JsHttpRequest' : '1-xml'})
    tokenkey = info['js']['token']
    return tokenkey
def getProfile(panelurl,mac,tokenkey,timezone):
    values = {
        'type' : 'stb', 
        'action' : 'get_profile',
        'hd' : '1',
        'ver' : 'ImageDescription:%200.2.18-r11-pub-254;%20ImageDate:%20Wed%20Mar%2018%2018:09:40%20EET%202015;%20PORTAL%20version:%204.9.14;%20API%20Version:%20JS%20API%20version:%20331;%20STB%20API%20version:%20141;%20Player%20Engine%20version:%200x572',
        'num_banks' : '1',
        'stb_type' : 'MAG254',
        'image_version' : '218',
        'auth_second_step' : '0',
        'hw_version' : '2.6-IB-00',
        'not_valid_token' : '0',
        'JsHttpRequest' : '1-xml'}
    info = Datasearch(panelurl,mac,tokenkey,timezone,values);
    passfalse = info['js']['password']
    if not passfalse !="":
        values = {
            'type' : 'stb', 
            'action' : 'get_profile'}
        info = Datasearch(panelurl,mac,tokenkey,timezone,values);
        timezone = info['js']['default_timezone']
        return timezone
    else:
        timezone = info['js']['default_timezone']
        return timezone
def Datasearch(panelurl,mac,tokenkey,timezone,values):
    if not tokenkey !="":
        tokenkey = ""
    else:
        tokenkey = tokenkey
    if not timezone !="":
        timezone = 'America/Chicago';
    else:
        timezone = timezone
    user_agent 	= 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 4 rev: 1812 Mobile Safari/533.3';
    try:
        if not tokenkey !="":
            headers = {
                'User-Agent' : user_agent, 
                'Cookie' : 'mac=' + mac+ '; stb_lang=en; timezone=' + timezone,
                'Referer' : panelurl,
                'Accept' : '*/*',
                'Connection' : 'Keep-Alive',
                'X-User-Agent' : 'Model: MAG254; Link: Ethernet'};
        else:
            headers = { 
                'User-Agent' : user_agent, 
                'Cookie' : 'mac=' + mac + '; stb_lang=en; timezone=' + timezone,
                'Referer' : panelurl,
                'Accept' : '*/*',
                'Connection' : 'Keep-Alive',
                'X-User-Agent' : 'Model: MAG254; Link: Ethernet',
                'Authorization' : 'Bearer ' + tokenkey };

        load = "/server/load.php"
        data = urllib.parse.urlencode(values)
        # data = (urllib.parse.urlencode(values)).replace("%3A", ":").replace("%2A", "*")
        # data = urlencode(values, quote_via=quote_plus)
        rs = requests.get(panelurl + load + '?' + data, headers=headers)
        return rs.json()
    except:
        return playList.clear(exit())
######################################
def xttplaymac(filename,name,method,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo):#addDirxbmctrtools
    if thumbfolder != "":
        thumbfolder = os.path.join(images_path, thumbfolder+".png")
    u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&method="+str(method)+"&name="+urllib.parse.quote_plus(name)+"&thumbnail="+urllib.parse.quote_plus(thumbnail)+"&thumbfolder="+urllib.parse.quote_plus(thumbfolder)+"&filename="+urllib.parse.quote_plus(filename)+"&fix="+urllib.parse.quote_plus(fix)+"&mac="+urllib.parse.quote_plus(mac)+"&timezone="+urllib.parse.quote_plus(timezone)+"&tokenkey="+urllib.parse.quote_plus(tokenkey)+"&playinfo="+urllib.parse.quote_plus(playinfo)
    liz=xbmcgui.ListItem(name)
    liz.setArt({'thumb': thumbnail or thumbfolder})
    liz.setInfo(type="Video", infoLabels={"Title": name})
    # liz.setProperty('fanart_image', thumbnail or thumbfolder)
    liz.setProperty('fanart_image', Fanart) or ("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
def xttplaymeta(filename,method,title,name,sezon,bolum,thumbnail,thumbfolder,panelurl,mac,tokenkey,timezone,cmd,data1,data2,data3,data4,data5,data6,metainfo):
    if thumbfolder != "":
        thumbfolder = os.path.join(images_path, thumbfolder+".png")
    liz=xbmcgui.ListItem(name)
    liz.setArt({'thumb': thumbnail or thumbfolder})
    liz.setInfo(type="Video", infoLabels={"plot": str(metainfo)})
    liz.setProperty('fanart_image', thumbnail or thumbfolder) or ("IsPlayable", "true")
    u=sys.argv[0]+"?&filename="+urllib.parse.quote_plus(filename)+"&method="+str(method)+"&title="+urllib.parse.quote_plus(title)+"&name="+urllib.parse.quote_plus(name)+"&sezon="+urllib.parse.quote_plus(sezon)+"&bolum="+urllib.parse.quote_plus(bolum)+"&thumbnail="+urllib.parse.quote_plus(thumbnail)+"&thumbfolder="+urllib.parse.quote_plus(thumbfolder)+"&panelurl="+urllib.parse.quote_plus(panelurl)+"&mac="+urllib.parse.quote_plus(mac)+"&tokenkey="+urllib.parse.quote_plus(tokenkey)+"&timezone="+urllib.parse.quote_plus(timezone)+"&cmd="+urllib.parse.quote_plus(cmd)+"&data1="+urllib.parse.quote_plus(data1)+"&data2="+urllib.parse.quote_plus(data2)+"&data3="+urllib.parse.quote_plus(data3)+"&data4="+urllib.parse.quote_plus(data4)+"&data5="+urllib.parse.quote_plus(data5)+"&data6="+urllib.parse.quote_plus(data6)+"&metainfo="+urllib.parse.quote_plus(str(metainfo))
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
def replace_fix(x):
    x=x.replace("\\n", "").replace("\n", "").replace("', '", "\n").replace('", "', "\n").replace('\', "', "\n").replace('", \'', "\n").replace("['", "").replace('["', "").replace("']", "").replace('"]', "").replace('Monday', "Pazartesi").replace('Tuesday', "Salı").replace('Wednesday', "Çarşamba").replace('Thursday', "Perşembe").replace('Friday', "Cuma").replace('Saturday', "Cumartesi").replace('Sunday', "Pazar")
    return x